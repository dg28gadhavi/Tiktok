from PyQt6.QtWidgets import QMainWindow, QStatusBar
from ui_setup import setup_ui
from file_handling import select_file
from scraping import start_scraping, stop_scraping, update_progress, update_log, handle_error, scraping_finished, reset_ui_state
from utils import check_vpn_connection
from typing import List

class MainWindow(QMainWindow):
    """Main application window with improved UI and error handling."""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TikTok Profile Scraper")
        self.setMinimumSize(1000, 800)

        # Set up status bar first
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        self.status_bar.setStyleSheet("""
            QStatusBar {
                background-color: #000000;
                color: #00ff00;
                border-top: 1px solid #00ff00;
            }
        """)

        # Then set up UI and check VPN
        setup_ui(self)
        check_vpn_connection(self.log_text, self.status_bar)
        self.worker = None

    def select_file(self):
        select_file(self)

    def start_scraping(self):
        start_scraping(self)

    def stop_scraping(self):
        stop_scraping(self)

    def update_progress(self, value: int):
        update_progress(self, value)

    def update_log(self, message: str):
        update_log(self, message)

    def handle_error(self, error_message: str):
        handle_error(self, error_message)

    def scraping_finished(self, results: List[List[str]]):
        scraping_finished(self, results)

    def reset_ui_state(self):
        reset_ui_state(self)
