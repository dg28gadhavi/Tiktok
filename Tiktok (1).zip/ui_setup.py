from PyQt6.QtWidgets import QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QSpinBox, QTextEdit, QWidget, QProgressBar
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from logging_setup import setup_logging

def setup_ui(main_window):
    """Set up the user interface with improved layout and styling."""
    main_layout = QVBoxLayout()

    # File selection section with green styling
    file_section = QHBoxLayout()
    main_window.file_label = QLabel("No file selected")
    main_window.file_label.setStyleSheet("color: #00ff00;")
    main_window.file_button = QPushButton("Select Excel File")
    main_window.file_button.setStyleSheet("""
        QPushButton {
            background-color: #000000;
            color: #00ff00;
            border: 1px solid #00ff00;
            padding: 5px 15px;
            border-radius: 3px;
        }
        QPushButton:hover {
            background-color: #003300;
        }
    """)
    main_window.file_button.clicked.connect(main_window.select_file)
    file_section.addWidget(main_window.file_label)
    file_section.addWidget(main_window.file_button)

    # Settings section
    settings_section = QHBoxLayout()
    settings_section.setSpacing(20)

    # Common style for labels and spinboxes
    label_style = "color: #00ff00;"
    spinbox_style = """
        QSpinBox {
            background-color: #000000;
            color: #00ff00;
            border: 1px solid #00ff00;
            padding: 2px;
            border-radius: 3px;
        }
        QSpinBox::up-button, QSpinBox::down-button {
            background-color: #003300;
            border: 1px solid #00ff00;
        }
    """

    # Batch size settings
    batch_container = QVBoxLayout()
    batch_label = QLabel("Batch Size:")
    batch_label.setStyleSheet(label_style)
    main_window.batch_spin = QSpinBox()
    main_window.batch_spin.setStyleSheet(spinbox_style)
    main_window.batch_spin.setRange(1, 1000)
    main_window.batch_spin.setValue(50)
    batch_container.addWidget(batch_label)
    batch_container.addWidget(main_window.batch_spin)

    # Timeout settings
    timeout_container = QVBoxLayout()
    timeout_label = QLabel("Timeout (seconds):")
    timeout_label.setStyleSheet(label_style)
    main_window.timeout_spin = QSpinBox()
    main_window.timeout_spin.setStyleSheet(spinbox_style)
    main_window.timeout_spin.setRange(1, 300)
    main_window.timeout_spin.setValue(30)
    timeout_container.addWidget(timeout_label)
    timeout_container.addWidget(main_window.timeout_spin)

    # Retry settings
    retry_container = QVBoxLayout()
    retry_label = QLabel("Max Retries:")
    retry_label.setStyleSheet(label_style)
    main_window.retry_spin = QSpinBox()
    main_window.retry_spin.setStyleSheet(spinbox_style)
    main_window.retry_spin.setRange(1, 10)
    main_window.retry_spin.setValue(3)
    retry_container.addWidget(retry_label)
    retry_container.addWidget(main_window.retry_spin)

    settings_section.addLayout(batch_container)
    settings_section.addLayout(timeout_container)
    settings_section.addLayout(retry_container)

    # Progress bar with green styling
    main_window.progress_bar = QProgressBar()
    main_window.progress_bar.setTextVisible(True)
    main_window.progress_bar.setStyleSheet("""
        QProgressBar {
            background-color: #000000;
            border: 1px solid #00ff00;
            color: #00ff00;
            border-radius: 3px;
            text-align: center;
        }
        QProgressBar::chunk {
            background-color: #003300;
        }
    """)

    # Log text area with AMOLED black background and custom styling
    main_window.log_text = QTextEdit()
    main_window.log_text.setReadOnly(True)
    main_window.log_text.setFont(QFont("Courier New", 10))
    main_window.log_text.setStyleSheet("""
        QTextEdit {
            background-color: #000000;  /* AMOLED black */
            color: #00ff00;  /* Hacker green */
            border: 1px solid #00ff00;  /* Hacker green border */
            border-radius: 5px;
            padding: 5px;
        }
        QScrollBar:vertical {
            background-color: #000000;
            width: 12px;
            margin: 0px;
        }
        QScrollBar::handle:vertical {
            background-color: #00ff00;
            border-radius: 6px;
            min-height: 20px;
        }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0px;
        }
        QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
            background-color: #000000;
        }
    """)

    # Set up logging with HTML formatting enabled
    setup_logging(main_window.log_text, main_window.status_bar, main_window.progress_bar)

    # Control buttons with improved styling
    button_section = QHBoxLayout()
    main_window.start_button = QPushButton("Start Scraping")
    main_window.stop_button = QPushButton("Stop")

    # Start button styling - bright green
    main_window.start_button.setStyleSheet("""
        QPushButton {
            padding: 8px 20px;
            border-radius: 5px;
            background-color: #00ff00;
            color: black;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #00cc00;
        }
        QPushButton:disabled {
            background-color: #004400;
            color: #666666;
        }
    """)

    # Stop button styling - bright red
    main_window.stop_button.setStyleSheet("""
        QPushButton {
            padding: 8px 20px;
            border-radius: 5px;
            background-color: #ff0000;
            color: white;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #cc0000;
        }
        QPushButton:disabled {
            background-color: #440000;
            color: #666666;
        }
    """)

    main_window.start_button.clicked.connect(main_window.start_scraping)
    main_window.stop_button.clicked.connect(main_window.stop_scraping)
    main_window.stop_button.setEnabled(False)

    button_section.addWidget(main_window.start_button)
    button_section.addWidget(main_window.stop_button)

    # Add all sections to main layout
    main_layout.addLayout(file_section)
    main_layout.addLayout(settings_section)
    main_layout.addWidget(main_window.progress_bar)
    main_layout.addWidget(main_window.log_text)
    main_layout.addLayout(button_section)

    # Set up central widget
    central_widget = QWidget()
    central_widget.setLayout(main_layout)
    main_window.setCentralWidget(central_widget)
