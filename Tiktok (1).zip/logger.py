import logging
from PyQt6.QtWidgets import QTextEdit, QStatusBar, QProgressBar

class QTextEditLogger(logging.Handler):
    """Custom logging handler that redirects logs to QTextEdit widget with colored output."""
    def __init__(self, text_widget: QTextEdit, status_bar: QStatusBar, progress_bar: QProgressBar):
        super().__init__()
        self.text_widget = text_widget
        self.status_bar = status_bar
        self.progress_bar = progress_bar

    def emit(self, record):
        # Color codes for different message types - using bright, visible colors
        COLORS = {
            'INFO': '#00ff00',    # Bright green
            'WARNING': '#ffff00',  # Bright yellow
            'ERROR': '#ff0000',    # Bright red
            'CRITICAL': '#ff0000', # Bright red
            'DEBUG': '#00ff00'     # Bright green
        }

        # Get the color for this log level
        color = COLORS.get(record.levelname, '#00ff00')

        # Format timestamp in bright green
        timestamp = f'<span style="color: #00ff00;">{self.format(record).split(" - ")[0]}</span>'

        # Format level name in its respective color
        level = f'<span style="color: {color};">{record.levelname}</span>'

        # Format message
        msg = record.getMessage()

        # Special formatting for warnings (bright yellow)
        if record.levelname == 'WARNING':
            warning_symbol = '<span style="color: #ffff00;">⚠️</span>'
            msg = f'{warning_symbol} <span style="color: #ffff00;">{msg}</span>'

        # Special formatting for errors (bright red)
        elif record.levelname in ['ERROR', 'CRITICAL']:
            msg = f'<span style="color: #ff0000;">{msg}</span>'
        else:
            msg = f'<span style="color: #00ff00;">{msg}</span>'

        # Combine all parts
        html_text = f"{timestamp} - {level} - {msg}"

        # Append the formatted text
        self.text_widget.append(html_text)
        self.text_widget.verticalScrollBar().setValue(
            self.text_widget.verticalScrollBar().maximum()
        )

        # Update the status bar style for better visibility
        self.status_bar.setStyleSheet("""
            QStatusBar {
                background-color: #000000;
                color: #00ff00;
                border-top: 1px solid #00ff00;
                font-weight: bold;
            }
        """)

        # Update progress bar with brighter colors
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #000000;
                border: 1px solid #00ff00;
                color: black;
                border-radius: 3px;
                text-align: center;
                font-weight: bold;
            }
            QProgressBar::chunk {
                background-color: #00ff00;
            }
        """)
