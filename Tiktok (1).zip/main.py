import sys
from PyQt6.QtWidgets import QApplication
from main_window import MainWindow

def main():
    """Main application entry point with error handling."""
    try:
        app = QApplication(sys.argv)

        # Set application style
        app.setStyle('Fusion')

        # Create and show main window
        main_window = MainWindow()
        main_window.show()

        # Start event loop
        sys.exit(app.exec())

    except Exception as e:
        print(f"Critical error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
