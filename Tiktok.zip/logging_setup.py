import logging
from logger import QTextEditLogger

def setup_logging(log_text, status_bar, progress_bar):
    """Set up logging with HTML formatting enabled."""
    log_handler = QTextEditLogger(log_text, status_bar, progress_bar)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    log_handler.setFormatter(formatter)
    logging.getLogger().addHandler(log_handler)
    logging.getLogger().setLevel(logging.INFO)
