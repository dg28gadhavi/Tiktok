from PyQt6.QtWidgets import QFileDialog, QMessageBox
from openpyxl import load_workbook
import os

def select_file(main_window):
    """Handle file selection with improved error checking."""
    file_name, _ = QFileDialog.getOpenFileName(
        main_window,
        "Select Excel File",
        "",
        "Excel Files (*.xlsx *.xls)"
    )

    if file_name:
        try:
            # Verify file can be opened
            wb = load_workbook(file_name, read_only=True)
            wb.close()

            main_window.file_label.setText(file_name)
            main_window.file_label.setStyleSheet("color: green;")
            main_window.status_bar.showMessage(f"Selected file: {os.path.basename(file_name)}")
        except Exception as e:
            QMessageBox.critical(main_window, "Error", f"Cannot open file: {str(e)}")
            main_window.file_label.setText("No file selected")
            main_window.file_label.setStyleSheet("")
