import re
import time
import subprocess
import sys
import platform
from typing import List, Optional
from PyQt6.QtCore import QThread, pyqtSignal
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from openpyxl import load_workbook
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_exception_type

def install_playwright_drivers():
    """
    Cross-platform method to install Playwright Firefox driver.
    Handles different operating systems and Python environments.
    """
    def run_command(cmd):
        try:
            # Use subprocess to run the command
            result = subprocess.run(
                cmd, 
                shell=True, 
                check=True, 
                capture_output=True, 
                text=True
            )
            print("Playwright installation output:", result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"Error installing Playwright: {e}")
            print("Error output:", e.stderr)
            raise

    # Determine the appropriate installation method
    current_os = platform.system().lower()
    python_executable = sys.executable

    if current_os == 'windows':
        # Windows:
        try:
            run_command(f'playwright install firefox')
        except:
            # Fallback method
            run_command('playwright install firefox')
    elif current_os in ['linux', 'darwin']:  # Linux or macOS
        try:
            # Prefer pip-installed playwright
            run_command(f'playwright install firefox')
        except:
            # Fallback to global playwright
            run_command('playwright install firefox')
    else:
        raise OSError(f"Unsupported operating system: {current_os}")

# Call Playwright installation at module import
try:
    install_playwright_drivers()
except Exception as e:
    print(f"Failed to install Playwright drivers: {e}")
    sys.exit(1)

class ScraperWorker(QThread):
    """Worker thread for scraping TikTok profiles."""
    progress_updated = pyqtSignal(int)
    log_updated = pyqtSignal(str)
    finished = pyqtSignal(list)
    error_occurred = pyqtSignal(str)

    def __init__(self, excel_file: str, batch_size: int, timeout: int, max_retries: int):
        super().__init__()
        self.excel_file = excel_file
        self.batch_size = batch_size
        self.timeout = timeout
        self.max_retries = max_retries
        self.is_running = True
        self.results = []

    def extract_email(self, bio_text: str) -> Optional[str]:
        """Extract email addresses from bio text using improved regex patterns."""
        if not bio_text:
            return None

        # Common email obfuscation patterns
        patterns = [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # Standard email
            r'[a-zA-Z0-9._%+-]+\s*[\[{\(]at[\]}\)]\s*[a-zA-Z0-9.-]+\s*[\[{\(]dot[\]}\)]\s*[a-zA-Z]{2,}',  # (at) (dot)
            r'[a-zA-Z0-9._%+-]+\s+at\s+[a-zA-Z0-9.-]+\s+dot\s+[a-zA-Z]{2,}'  # Plain text "at dot"
        ]

        # Clean the text
        cleaned_text = bio_text.lower()
        cleaned_text = re.sub(r'\s+dot\s+', '.', cleaned_text)
        cleaned_text = re.sub(r'\s+at\s+', '@', cleaned_text)
        cleaned_text = re.sub(r'[\[{\(]at[\]}\)]', '@', cleaned_text)
        cleaned_text = re.sub(r'[\[{\(]dot[\]}\)]', '.', cleaned_text)

        # Try each pattern
        for pattern in patterns:
            match = re.search(pattern, cleaned_text)
            if match:
                return match.group()
        return None

    @retry(stop=stop_after_attempt(3),
           wait=wait_fixed(2),
           retry=retry_if_exception_type((PlaywrightTimeoutError,)))
    def extract_profile_data(self, page, username: str) -> List[str]:
        """Extract user bio, email, and a single external link from TikTok profile."""
        profile_url = f"https://www.tiktok.com/@{username}"
        self.log_updated.emit(f"Accessing profile: @{username}")

        try:
            page.goto(profile_url, timeout=self.timeout * 1000)

            # Get bio
            try:
                bio_element = page.query_selector('h2[data-e2e="user-bio"]')
                bio = bio_element.inner_text() if bio_element else "Bio not found"
            except PlaywrightTimeoutError:
                bio = "Bio not found"

            # Get name with fallback
            try:
                name_element = page.query_selector('h2[data-e2e="user-subtitle"]')
                name = name_element.inner_text() if name_element else "N/A"
            except PlaywrightTimeoutError:
                name = "N/A"

            # Extract a single external link
            try:
                link_element = page.query_selector('span.css-847r2g-SpanLink.eht0fek2')
                external_link = link_element.inner_text() if link_element else "No external link found"
            except PlaywrightTimeoutError:
                external_link = "No external link found"

            email = self.extract_email(bio)
            return [username, name, email or "No email found", external_link]

        except Exception as e:
            self.log_updated.emit(f"Error processing @{username}: {str(e)}")
            return [username, "Error", "Failed to extract", "Failed to extract link"]

    def run(self):
        """Main scraping process with improved error handling and progress tracking."""
        try:
            # Load usernames from Excel
            wb = load_workbook(self.excel_file, read_only=True, data_only=True)
            ws = wb.active
            usernames = [row[0].value for row in ws.iter_rows(min_row=2, min_col=2, max_col=2)
                        if row[0].value]  # Filter out None/empty values

            if not usernames:
                self.error_occurred.emit("No usernames found in Excel file")
                return

            processed = 0

            with sync_playwright() as p:
                browser = p.firefox.launch(headless=True)  # Launch Firefox instead of Chromium
                context = browser.new_context()
                page = context.new_page()

                try:
                    for i in range(0, len(usernames), self.batch_size):
                        if not self.is_running:
                            self.log_updated.emit("Scraping stopped by user")
                            break

                        batch = usernames[i:i + self.batch_size]

                        for username in batch:
                            if not self.is_running:
                                break

                            try:
                                result = self.extract_profile_data(page, username)
                                self.results.append(result)
                            except Exception as e:
                                self.log_updated.emit(f"Failed to process @{username}: {str(e)}")
                                self.results.append([username, "Error", "Processing failed", "Failed to extract link"])

                            processed += 1
                            progress = int((processed / len(usernames)) * 100)
                            self.progress_updated.emit(progress)

                            # Add small delay between requests
                            time.sleep(1)

                finally:
                    browser.close()

            self.finished.emit(self.results)

        except Exception as e:
            self.error_occurred.emit(f"Critical error: {str(e)}")
            self.log_updated.emit(f"Scraping failed: {str(e)}")

    def stop(self):
        """Safely stop the scraping process."""
        self.is_running = False
        self.log_updated.emit("Stopping scraper (completing current batch)...")