from PyQt6.QtWidgets import QMessageBox
from scraper import ScraperWorker
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Alignment
from openpyxl.utils import get_column_letter
from email_decomposer.EmailDecomposer import EmailDecomposer
import os
from datetime import datetime
from typing import List

def start_scraping(main_window):
    """Start the scraping process with improved validation."""
    if not main_window.file_label.text() or main_window.file_label.text() == "No file selected":
        QMessageBox.warning(main_window, "Warning", "Please select an Excel file first.")
        return

    try:
        # Get settings values
        batch_size = main_window.batch_spin.value()
        timeout = main_window.timeout_spin.value()
        retries = main_window.retry_spin.value()

        # Initialize worker thread
        main_window.worker = ScraperWorker(
            main_window.file_label.text(),
            batch_size,
            timeout,
            retries
        )

        # Connect signals
        main_window.worker.progress_updated.connect(lambda value: update_progress(main_window, value))
        main_window.worker.log_updated.connect(lambda message: update_log(main_window, message))
        main_window.worker.finished.connect(lambda results: scraping_finished(main_window, results))
        main_window.worker.error_occurred.connect(lambda error_message: handle_error(main_window, error_message))

        # Update UI state
        main_window.start_button.setEnabled(False)
        main_window.stop_button.setEnabled(True)
        main_window.file_button.setEnabled(False)
        main_window.batch_spin.setEnabled(False)
        main_window.timeout_spin.setEnabled(False)
        main_window.retry_spin.setEnabled(False)

        # Start scraping
        main_window.worker.start()
        main_window.status_bar.showMessage("Scraping in progress...")
        main_window.log_text.append("Started scraping process...")

    except Exception as e:
        QMessageBox.critical(main_window, "Error", f"Failed to start scraping: {str(e)}")
        reset_ui_state(main_window)

def stop_scraping(main_window):
    """Safely stop the scraping process."""
    if main_window.worker and main_window.worker.isRunning():
        reply = QMessageBox.question(
            main_window,
            "Confirm Stop",
            "Are you sure you want to stop the scraping process?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            main_window.worker.stop()
            main_window.status_bar.showMessage("Stopping scraper...")
            main_window.log_text.append("Stopping scraper (completing current batch)...")
            main_window.stop_button.setEnabled(False)

def update_progress(main_window, value: int):
    """Update progress bar and status."""
    main_window.progress_bar.setValue(value)
    main_window.progress_bar.setFormat(f"{value}% Completed")
    main_window.status_bar.showMessage(f"Progress: {value}%")

def update_log(main_window, message: str):
    """Update log with new message."""
    main_window.log_text.append(message)
    # Ensure latest message is visible
    main_window.log_text.verticalScrollBar().setValue(
        main_window.log_text.verticalScrollBar().maximum()
    )

def handle_error(main_window, error_message: str):
    """Handle errors during scraping."""
    QMessageBox.critical(main_window, "Error", error_message)
    reset_ui_state(main_window)
    main_window.status_bar.showMessage("Error occurred during scraping")

def scraping_finished(main_window, results: List[List[str]]):
    """Handle completion of scraping process and save results."""
    try:
        if results:
            # Generate unique filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"TikTok_Results_{timestamp}.xlsx"

            # Get the current working directory
            current_dir = os.getcwd()

            # Construct the full file path
            output_path = os.path.join(current_dir, output_file)

            # Create a new workbook and select the active worksheet
            wb = Workbook()
            ws = wb.active
            ws.title = "TikTok Results"

            # Define header
            headers = ["Username", "Profile Name", "First Name", "Last Name", "Email", "External Link",
                       "Total Number of Username", "Total Number of Profile Name",
                       "Total Number of First Name", "Total Number of Last Name",
                       "Total Number of Email", "Total Number of External Link"]
            ws.append(headers)

            # Define cell styles
            red_fill = PatternFill(start_color="FFFF0000", end_color="FFFF0000", fill_type="solid")
            green_fill = PatternFill(start_color="FF00FF00", end_color="FF00FF00", fill_type="solid")
            yellow_fill = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
            blue_fill = PatternFill(start_color="FF0000FF", end_color="FF0000FF", fill_type="solid")
            pink_fill = PatternFill(start_color="FFFFC0CB", end_color="FFFFC0CB", fill_type="solid")
            black_fill = PatternFill(start_color="FF000000", end_color="FF000000", fill_type="solid")

            # Apply blue fill to the header row
            for cell in ws[1]:
                cell.fill = blue_fill

            # Set column widths
            ws.column_dimensions[get_column_letter(1)].width = 18.25
            ws.column_dimensions[get_column_letter(2)].width = 18.25
            ws.column_dimensions[get_column_letter(3)].width = 15
            ws.column_dimensions[get_column_letter(4)].width = 15
            ws.column_dimensions[get_column_letter(5)].width = 27.375
            ws.column_dimensions[get_column_letter(6)].width = 27.375
            ws.column_dimensions[get_column_letter(7)].width = 22.8125
            ws.column_dimensions[get_column_letter(8)].width = 22.8125
            ws.column_dimensions[get_column_letter(9)].width = 22.8125
            ws.column_dimensions[get_column_letter(10)].width = 22.8125
            ws.column_dimensions[get_column_letter(11)].width = 22.8125
            ws.column_dimensions[get_column_letter(12)].width = 22.8125

            # Write results to the worksheet
            for row in results:
                email = row[2]  # Assuming the email is in the third column
                if email and email.lower() != "n/a" and email.lower() != "no email found":
                    decomposed_email = EmailDecomposer().decompose(data=email, get_host=True)
                    first_name = decomposed_email.get('first_name', 'N/A')
                    last_name = decomposed_email.get('last_name', 'N/A')
                else:
                    first_name = 'N/A'
                    last_name = 'N/A'

                # Set fallback values for empty first name and last name
                if not first_name:
                    first_name = "Not Found"
                if not last_name:
                    last_name = "Not Found"

                extended_row = [row[0], row[1], first_name, last_name, row[2], row[3]]
                ws.append(extended_row)

            # Apply styles based on fallback values
            fallback_values = ["Bio not found", "N/A", "No external link found", "Error", "Failed to extract", "Processing failed", "No email found", "Not Found"]

            total_usernames = len(results)
            username_fallbacks = 0
            profile_name_fallbacks = 0
            email_fallbacks = 0
            link_fallbacks = 0
            first_name_fallbacks = 0
            last_name_fallbacks = 0

            for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=6):
                username_cell = row[0]
                profile_name_cell = row[1]
                first_name_cell = row[2]
                last_name_cell = row[3]
                email_cell = row[4]
                link_cell = row[5]

                row_has_fallback = any(cell.value in fallback_values for cell in [profile_name_cell, email_cell, first_name_cell])

                if row_has_fallback or first_name_cell.value == "Not Found":
                    username_cell.fill = yellow_fill
                    username_fallbacks += 1
                else:
                    username_cell.fill = green_fill

                for cell in [profile_name_cell, email_cell, link_cell, first_name_cell, last_name_cell]:
                    if cell.value in fallback_values:
                        cell.fill = red_fill
                        if cell == profile_name_cell:
                            profile_name_fallbacks += 1
                        elif cell == email_cell:
                            email_fallbacks += 1
                        elif cell == link_cell:
                            link_fallbacks += 1
                        elif cell == first_name_cell:
                            first_name_fallbacks += 1
                        elif cell == last_name_cell:
                            last_name_fallbacks += 1
                    else:
                        cell.fill = green_fill

            # Calculate totals
            total_username = total_usernames
            total_profile_name = total_usernames - profile_name_fallbacks
            total_email = total_usernames - email_fallbacks
            total_link = total_usernames - link_fallbacks
            total_first_name = total_usernames - first_name_fallbacks
            total_last_name = total_usernames - last_name_fallbacks

            # Append totals to the worksheet
            totals_row = [
                "", "", "", "", "", "",
                total_username, total_profile_name, total_first_name, total_last_name,
                total_email, total_link
            ]
            ws.append(totals_row)

            # Apply pink fill and center alignment to the totals row
            for cell in ws[ws.max_row]:
                cell.fill = pink_fill
                cell.alignment = Alignment(horizontal='center')

            # Highlight empty cells in black
            for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=7, max_col=12):
                for cell in row:
                    if cell.value is None:
                        cell.fill = black_fill

            # Save the workbook
            wb.save(output_path)

            # Show success message
            QMessageBox.information(
                main_window,
                "Success",
                f"Scraping completed successfully!\nResults saved to: {output_path}"
            )

            main_window.log_text.append(f"Results saved to: {output_path}")
            main_window.status_bar.showMessage("Scraping completed successfully")
        else:
            QMessageBox.warning(
                main_window,
                "Warning",
                "Scraping completed but no results were obtained."
            )

    except Exception as e:
        QMessageBox.critical(
            main_window,
            "Error",
            f"Failed to save results: {str(e)}"
        )

    finally:
        reset_ui_state(main_window)

def reset_ui_state(main_window):
    """Reset UI elements to initial state."""
    main_window.start_button.setEnabled(True)
    main_window.stop_button.setEnabled(False)
    main_window.file_button.setEnabled(True)
    main_window.batch_spin.setEnabled(True)
    main_window.timeout_spin.setEnabled(True)
    main_window.retry_spin.setEnabled(True)
    main_window.progress_bar.setValue(0)
    main_window.worker = None
