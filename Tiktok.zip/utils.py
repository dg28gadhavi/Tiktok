import requests
from PyQt6.QtWidgets import QTextEdit, QStatusBar

def check_vpn_connection(log_text: QTextEdit, status_bar: QStatusBar):
    """Check VPN connection status with improved error handling."""
    try:
        # Use a longer timeout and add headers
        response = requests.get(
            "https://www.tiktok.com",
            timeout=10,  # Increased timeout
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            },
            allow_redirects=False
        )

        if response.status_code == 403:
            log_text.append("⚠️ Warning: TikTok access blocked. Please check your VPN connection.")
            status_bar.showMessage("VPN check: Access blocked")
        else:
            log_text.append("✅ Network connection established successfully.")
            status_bar.showMessage("VPN check: Connected")

    except requests.exceptions.ReadTimeout:
        log_text.append("⚠️ Warning: Connection timed out. Please check your network/VPN connection.")
        status_bar.showMessage("VPN check: Timeout")
    except requests.exceptions.ConnectionError:
        log_text.append("⚠️ Warning: Unable to connect. Please check your network/VPN connection.")
        status_bar.showMessage("VPN check: Connection failed")
    except Exception as e:
        log_text.append(f"⚠️ Warning: Network check failed - {str(e)}")
        status_bar.showMessage("VPN check: Error")
    finally:
        # Continue program execution regardless of connection status
        log_text.append("Program ready to start...")
